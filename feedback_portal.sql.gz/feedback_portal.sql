-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 25, 2019 at 02:31 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `feedback_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_list`
--

DROP TABLE IF EXISTS `category_list`;
CREATE TABLE IF NOT EXISTS `category_list` (
  `name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_list`
--

INSERT INTO `category_list` (`name`) VALUES
('Student'),
('Faculty');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `admin` varchar(20) DEFAULT NULL,
  `password` varchar(75) DEFAULT NULL,
  `type` varchar(1) NOT NULL DEFAULT 'F'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`name`, `description`, `admin`, `password`, `type`) VALUES
('SCET', 'School of Computer Engineering & Technology', 'scet', '$2y$10$ss.g39szkFKeBqzYvg8pkeHGaFs8gY5crlToRymCSf2KihgOl5fru', 'F'),
('SMCE', 'School of Mechanical & Civil Engineering', 'smce', '$2y$10$QvCpXO6JDrpQnj23zuqG4OEFu.drugGa2ClgqSYXk6LEgviMJzeDW', 'F'),
('admin', 'admin', 'admin', '$2y$10$Mg9FN4DSzv6CYlzHSwxl6O3oZ1nQtRgk8bTrofO9SuN5lIWZvFL/i', 'A'),
('SHES', 'School of Humanities & Engineering Science', 'shes', '$2y$10$juneBKYPnqjOp5roI6lcXeQarUvzzSFkjZUPo94fHJEYBKBRUEpxq', 'F');

-- --------------------------------------------------------

--
-- Table structure for table `load_distribution`
--

DROP TABLE IF EXISTS `load_distribution`;
CREATE TABLE IF NOT EXISTS `load_distribution` (
  `dept` varchar(100) DEFAULT NULL,
  `year` varchar(20) DEFAULT NULL,
  `block` varchar(10) DEFAULT NULL,
  `faculty` varchar(50) DEFAULT NULL,
  `fac_abbr` varchar(4) DEFAULT NULL,
  `course` varchar(75) DEFAULT NULL,
  `course_abbr` varchar(5) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `load_distribution`
--

INSERT INTO `load_distribution` (`dept`, `year`, `block`, `faculty`, `fac_abbr`, `course`, `course_abbr`, `type`) VALUES
('SHES', 'FY', 'B1', 'Prabha S. Kasliwal', 'PSK', 'Electronics & Electrical Engineering', 'EEE', 'Theory'),
('SMCE', 'FY', 'B2', 'V.K.Pingle', 'VKP', 'Applied Mechanics', 'AM', 'Theory'),
('SMCE', 'TY', 'B3', 'P.R. Hatte', 'PRH', 'Heat & Thermodynamics', 'HT', 'Theory'),
('SCET', 'SY', 'B5', 'Pankaj Choudhary', 'PPC', 'Object Oriented Technology', 'OOT', 'Theory'),
('SCET', 'SY', 'B5', 'Pankaj Choduhary', 'PPC', 'Object Oriented Technology Lab', 'OOTL', 'Lab'),
('SCET', 'TY', 'B5', 'Sunil Mhamane', 'SSM', 'Computability Theory', 'CT', 'Theory'),
('SCET', 'TY', 'B5', 'Sunil Mhamane', 'SSM', 'Computability Theory Lab', 'CTL', 'Lab'),
('SCET', 'TY', 'B5', 'Pankaj Choudhary	', 'PPC', 'Web Technology', 'WT', 'Theory'),
('SCET', 'TY', 'B5', 'Pankaj Choudhary	', 'PPC', 'Web Technology Lab', 'WTL', 'Lab'),
('SCET', 'TY', 'B5', 'S M Bhagat', 'SMB', 'Operating System', 'OS', 'Theory'),
('SCET', 'TY', 'B5', 'S M Bhagat', 'SMB', 'Operating System Lab', 'OSL', 'Lab'),
('SCET', 'SY', 'B5', 'S M Bhagat', 'SMB', 'Computer Networking Technologies', 'CNT', 'Theory'),
('SMCE', 'TY', 'B5', 'V.K.Pingle', 'VKP', 'Fluid Mechanics', 'FM', 'Theory'),
('SMCE', 'TY', 'B5', 'V.K.Pingle', 'VKP', 'Fluid Mechanics Lab', 'FML', 'Lab'),
('SMCE', 'SY', 'B3', 'R.A.Sonawane', 'RAW', 'Aerodynamics', 'AD', 'Theory'),
('SMCE', 'SY', 'B3', 'R.A.Sonawane', 'RAW', 'Aerodynamics Lab', 'ADL', 'Lab'),
('SMCE', 'SY', 'B1', 'R.A.Sonawane', 'RAW', 'Aerodynamics', 'AD', 'Theory'),
('SMCE', 'SY', 'B1', 'R.A.Sonawane', 'RAW', 'Aerodynamics Lab', 'ADL', ''),
('SMCE', 'SY', 'B1', 'A.M.Murtuza', 'AMM', 'Mechanical Prototyping', 'MP', ''),
('SMCE', 'SY', 'B1', 'A.M.Murtuza', 'AMM', 'Mechanical Prototyping', 'MP', 'Theory'),
('SMCE', 'SY', 'B5', 'A.M.Murtuza', 'AMM', 'Mechanical Prototyping', 'MP', 'Theory'),
('SCET', 'SY', 'B1', 'P.P.Choudhary', 'PPC', 'Object Oriented Technology', 'OOT', 'Theory'),
('SCET', 'SY', 'B1', 'P.P.Choudhary', 'PPC', 'Object Oriented Technology Lab', 'OOTL', 'Lab'),
('SCET', 'SY', 'B3', 'Atul Choudhary', 'AC', 'Object Oriented Technology', 'OOT', 'Theory'),
('SCET', 'SY', 'B3', 'Atul Choudhary', 'AC', 'Object Oriented Technology Lab', 'OOTL', 'Lab'),
('SHES', 'SY', 'B1', 'Vitika Siddhabhatti', 'VS', 'Psychology Lab', 'PSYL', 'Lab'),
('SHES', 'SY', 'B1', 'Vitika Siddhabhatti', 'VS', 'Psychology', 'PSY', 'Theory'),
('SCET', 'TY', 'B1', 'Atul Choudhary', 'AC', 'Web Technology', 'WT', 'Theory'),
('SCET', 'TY', 'B1', 'Atul Choudhary', 'AC', 'Web Technology Lab', 'WTL', 'Lab'),
('SCET', 'TY', 'B3', 'P.P.Choudhary', 'PPC', 'Web Technology', 'WT', 'Theory'),
('SCET', 'TY', 'B3', 'P.P.Choudhary', 'PPC', 'Web Technology Lab', 'WTL', 'Lab'),
('SHES', 'TY', 'B1', 'Vitika Siddhabhatti', 'VS', 'Social Economics', 'SE', 'Theory'),
('SHES', 'TY', 'B1', 'Vitika Siddhabhatti', 'VS', 'Social Economics Lab', 'SEL', 'Lab'),
('SHES', 'SY', 'B3', 'Shweta Singh', 'SS', 'Psychology', 'PSY', 'Theory'),
('SHES', 'SY', 'B3', 'Shweta Singh', 'SS', 'Psychology Lab', 'PSYL', 'Lab'),
('SHES', 'TY', 'B3', 'Shweta Singh', 'SS', 'Social Economics', 'SE', 'Theory'),
('SHES', 'TY', 'B3', 'Shweta Singh', 'SS', 'Social Economics Lab', 'SEL', 'Lab');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `question` varchar(200) DEFAULT NULL,
  `option1` varchar(20) DEFAULT NULL,
  `option2` varchar(20) DEFAULT NULL,
  `option3` varchar(20) DEFAULT NULL,
  `option4` varchar(20) DEFAULT NULL,
  `option5` varchar(20) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `id` int(3) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question`, `option1`, `option2`, `option3`, `option4`, `option5`, `category`, `id`, `type`) VALUES
('SLQ1', '1a', '1b', '1c', '1d', NULL, 'Student', 1, 'lab'),
('STQ4', '4a', '4b', '4c', NULL, NULL, 'Student', 4, 'theory'),
('STQ3', '3a', '3b', '3c', '3d', '3e', 'Student', 3, 'theory'),
('STQ2', '2a', '2b', '2c', '2d', NULL, 'Student', 2, 'theory'),
('STQ1', '1a', '1b', '1c', '1d', '1e', 'Student', 1, 'theory');

-- --------------------------------------------------------

--
-- Table structure for table `response`
--

DROP TABLE IF EXISTS `response`;
CREATE TABLE IF NOT EXISTS `response` (
  `faculty` varchar(5) DEFAULT NULL,
  `course` varchar(5) DEFAULT NULL,
  `dept` varchar(10) NOT NULL,
  `year` varchar(4) NOT NULL,
  `block` varchar(3) NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  `qid` int(2) DEFAULT NULL,
  `score` int(2) DEFAULT NULL,
  `token` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `response`
--

INSERT INTO `response` (`faculty`, `course`, `dept`, `year`, `block`, `type`, `qid`, `score`, `token`) VALUES
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'aaaaaa'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'aaaaaa'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 1, 5, 'aaaaaa'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 2, 4, 'aaaaaa'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 2, 3, 'aaaaaa'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 2, 5, 'aaaaaa'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 3, 5, 'aaaaaa'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 3, 4, 'aaaaaa'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 3, 3, 'aaaaaa'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'aaaaaa'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'aaaaaa'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'aaaaaa'),
('SSM', 'CTL', 'SCET', 'TY', 'B5', 'lab', 1, 4, 'aaaaaa'),
('PPC', 'WTL', 'SCET', 'TY', 'B5', 'lab', 1, 3, 'aaaaaa'),
('SMB', 'OSL', 'SCET', 'TY', 'B5', 'lab', 1, 5, 'aaaaaa'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 1, 5, 'bbbbbb'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'bbbbbb'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'bbbbbb'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 2, 4, 'bbbbbb'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 2, 3, 'bbbbbb'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 2, 2, 'bbbbbb'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 3, 3, 'bbbbbb'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 3, 2, 'bbbbbb'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 3, 1, 'bbbbbb'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'bbbbbb'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 4, 4, 'bbbbbb'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 4, 5, 'bbbbbb'),
('SSM', 'CTL', 'SCET', 'TY', 'B5', 'lab', 1, 4, 'bbbbbb'),
('PPC', 'WTL', 'SCET', 'TY', 'B5', 'lab', 1, 4, 'bbbbbb'),
('SMB', 'OSL', 'SCET', 'TY', 'B5', 'lab', 1, 3, 'bbbbbb'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 1, 5, 'cccccc'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 1, 3, 'cccccc'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 1, 5, 'cccccc'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 2, 5, 'cccccc'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 2, 4, 'cccccc'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 2, 4, 'cccccc'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 3, 5, 'cccccc'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 3, 5, 'cccccc'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 3, 1, 'cccccc'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 4, 5, 'cccccc'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 4, 5, 'cccccc'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 4, 5, 'cccccc'),
('SSM', 'CTL', 'SCET', 'TY', 'B5', 'lab', 1, 4, 'cccccc'),
('PPC', 'WTL', 'SCET', 'TY', 'B5', 'lab', 1, 4, 'cccccc'),
('SMB', 'OSL', 'SCET', 'TY', 'B5', 'lab', 1, 4, 'cccccc'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 1, 5, 'dddddd'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 1, 5, 'dddddd'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 1, 5, 'dddddd'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 2, 5, 'dddddd'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 2, 5, 'dddddd'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 2, 5, 'dddddd'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 3, 5, 'dddddd'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 3, 5, 'dddddd'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 3, 5, 'dddddd'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 4, 5, 'dddddd'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 4, 5, 'dddddd'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 4, 5, 'dddddd'),
('SSM', 'CTL', 'SCET', 'TY', 'B5', 'lab', 1, 5, 'dddddd'),
('PPC', 'WTL', 'SCET', 'TY', 'B5', 'lab', 1, 5, 'dddddd'),
('SMB', 'OSL', 'SCET', 'TY', 'B5', 'lab', 1, 5, 'dddddd'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 1, 1, 'eeeeee'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 1, 1, 'eeeeee'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 1, 1, 'eeeeee'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 2, 2, 'eeeeee'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 2, 2, 'eeeeee'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 2, 2, 'eeeeee'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 3, 1, 'eeeeee'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 3, 1, 'eeeeee'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 3, 1, 'eeeeee'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'eeeeee'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'eeeeee'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'eeeeee'),
('SSM', 'CTL', 'SCET', 'TY', 'B5', 'lab', 1, 2, 'eeeeee'),
('PPC', 'WTL', 'SCET', 'TY', 'B5', 'lab', 1, 2, 'eeeeee'),
('SMB', 'OSL', 'SCET', 'TY', 'B5', 'lab', 1, 2, 'eeeeee'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 1, 3, 'ffffff'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'ffffff'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 1, 3, 'ffffff'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 2, 4, 'ffffff'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 2, 3, 'ffffff'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 2, 4, 'ffffff'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 3, 5, 'ffffff'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 3, 2, 'ffffff'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 3, 1, 'ffffff'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 4, 4, 'ffffff'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 4, 5, 'ffffff'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 4, 5, 'ffffff'),
('SSM', 'CTL', 'SCET', 'TY', 'B5', 'lab', 1, 5, 'ffffff'),
('PPC', 'WTL', 'SCET', 'TY', 'B5', 'lab', 1, 5, 'ffffff'),
('SMB', 'OSL', 'SCET', 'TY', 'B5', 'lab', 1, 5, 'ffffff'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'gggggg'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'gggggg'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'gggggg'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 2, 4, 'gggggg'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 2, 4, 'gggggg'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 2, 4, 'gggggg'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 3, 4, 'gggggg'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 3, 4, 'gggggg'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 3, 4, 'gggggg'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 4, 4, 'gggggg'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 4, 4, 'gggggg'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 4, 4, 'gggggg'),
('SSM', 'CTL', 'SCET', 'TY', 'B5', 'lab', 1, 3, 'gggggg'),
('PPC', 'WTL', 'SCET', 'TY', 'B5', 'lab', 1, 3, 'gggggg'),
('SMB', 'OSL', 'SCET', 'TY', 'B5', 'lab', 1, 3, 'gggggg'),
('PPC', 'OOT', 'SCET', 'SY', 'B1', 'theory', 1, 4, 'JGKRVP'),
('PPC', 'OOT', 'SCET', 'SY', 'B1', 'theory', 2, 5, 'JGKRVP'),
('PPC', 'OOT', 'SCET', 'SY', 'B1', 'theory', 3, 4, 'JGKRVP'),
('PPC', 'OOT', 'SCET', 'SY', 'B1', 'theory', 4, 3, 'JGKRVP'),
('PPC', 'OOTL', 'SCET', 'SY', 'B1', 'lab', 1, 4, 'JGKRVP'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'NWHMUC'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'NWHMUC'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 1, 3, 'NWHMUC'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 2, 5, 'NWHMUC'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 2, 3, 'NWHMUC'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 2, 2, 'NWHMUC'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 3, 2, 'NWHMUC'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 3, 5, 'NWHMUC'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 3, 4, 'NWHMUC'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 4, 4, 'NWHMUC'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'NWHMUC'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 4, 5, 'NWHMUC'),
('SSM', 'CTL', 'SCET', 'TY', 'B5', 'lab', 1, 3, 'NWHMUC'),
('PPC', 'WTL', 'SCET', 'TY', 'B5', 'lab', 1, 4, 'NWHMUC'),
('SMB', 'OSL', 'SCET', 'TY', 'B5', 'lab', 1, 3, 'NWHMUC'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 1, 1, 'JVVXSF'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 2, 2, 'JVVXSF'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 3, 1, 'JVVXSF'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 4, 3, 'JVVXSF'),
('AC', 'WTL', 'SCET', 'TY', 'B1', 'lab', 1, 2, 'JVVXSF'),
('PPC', 'OOT', 'SCET', 'SY', 'B5', 'theory', 1, 4, 'MHVMBB'),
('SMB', 'CNT', 'SCET', 'SY', 'B5', 'theory', 1, 4, 'MHVMBB'),
('PPC', 'OOT', 'SCET', 'SY', 'B5', 'theory', 2, 3, 'MHVMBB'),
('SMB', 'CNT', 'SCET', 'SY', 'B5', 'theory', 2, 3, 'MHVMBB'),
('PPC', 'OOT', 'SCET', 'SY', 'B5', 'theory', 3, 5, 'MHVMBB'),
('SMB', 'CNT', 'SCET', 'SY', 'B5', 'theory', 3, 4, 'MHVMBB'),
('PPC', 'OOT', 'SCET', 'SY', 'B5', 'theory', 4, 4, 'MHVMBB'),
('SMB', 'CNT', 'SCET', 'SY', 'B5', 'theory', 4, 4, 'MHVMBB'),
('PPC', 'OOTL', 'SCET', 'SY', 'B5', 'lab', 1, 5, 'MHVMBB'),
('PPC', 'OOT', 'SCET', 'SY', 'B1', 'theory', 1, 4, 'ZQQSOB'),
('PPC', 'OOT', 'SCET', 'SY', 'B1', 'theory', 2, 4, 'ZQQSOB'),
('PPC', 'OOT', 'SCET', 'SY', 'B1', 'theory', 3, 5, 'ZQQSOB'),
('PPC', 'OOT', 'SCET', 'SY', 'B1', 'theory', 4, 4, 'ZQQSOB'),
('PPC', 'OOTL', 'SCET', 'SY', 'B1', 'lab', 1, 5, 'ZQQSOB'),
('PPC', 'OOT', 'SCET', 'SY', 'B5', 'theory', 1, 5, 'HLOXDZ'),
('SMB', 'CNT', 'SCET', 'SY', 'B5', 'theory', 1, 4, 'HLOXDZ'),
('PPC', 'OOT', 'SCET', 'SY', 'B5', 'theory', 2, 4, 'HLOXDZ'),
('SMB', 'CNT', 'SCET', 'SY', 'B5', 'theory', 2, 3, 'HLOXDZ'),
('PPC', 'OOT', 'SCET', 'SY', 'B5', 'theory', 3, 3, 'HLOXDZ'),
('SMB', 'CNT', 'SCET', 'SY', 'B5', 'theory', 3, 3, 'HLOXDZ'),
('PPC', 'OOT', 'SCET', 'SY', 'B5', 'theory', 4, 3, 'HLOXDZ'),
('SMB', 'CNT', 'SCET', 'SY', 'B5', 'theory', 4, 4, 'HLOXDZ'),
('PPC', 'OOTL', 'SCET', 'SY', 'B5', 'lab', 1, 2, 'HLOXDZ'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 1, 5, 'CWCNKY'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 2, 5, 'CWCNKY'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 3, 5, 'CWCNKY'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 4, 5, 'CWCNKY'),
('AC', 'WTL', 'SCET', 'TY', 'B1', 'lab', 1, 5, 'CWCNKY'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 1, 4, 'PONTZT'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 2, 3, 'PONTZT'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 3, 4, 'PONTZT'),
('AC', 'WT', 'SCET', 'TY', 'B1', 'theory', 4, 3, 'PONTZT'),
('AC', 'WTL', 'SCET', 'TY', 'B1', 'lab', 1, 4, 'PONTZT'),
('AC', 'OOT', 'SCET', 'SY', 'B3', 'theory', 1, 3, 'FIRSSC'),
('AC', 'OOT', 'SCET', 'SY', 'B3', 'theory', 2, 4, 'FIRSSC'),
('AC', 'OOT', 'SCET', 'SY', 'B3', 'theory', 3, 3, 'FIRSSC'),
('AC', 'OOT', 'SCET', 'SY', 'B3', 'theory', 4, 4, 'FIRSSC'),
('AC', 'OOTL', 'SCET', 'SY', 'B3', 'lab', 1, 2, 'FIRSSC'),
('SS', 'PSY', 'SHES', 'SY', 'B3', 'theory', 1, 5, 'JLTXVV'),
('SS', 'PSY', 'SHES', 'SY', 'B3', 'theory', 2, 4, 'JLTXVV'),
('SS', 'PSY', 'SHES', 'SY', 'B3', 'theory', 3, 3, 'JLTXVV'),
('SS', 'PSY', 'SHES', 'SY', 'B3', 'theory', 4, 4, 'JLTXVV'),
('SS', 'PSYL', 'SHES', 'SY', 'B3', 'lab', 1, 4, 'JLTXVV'),
('VS', 'SE', 'SHES', 'TY', 'B1', 'theory', 1, 3, 'OOHVID'),
('VS', 'SE', 'SHES', 'TY', 'B1', 'theory', 2, 3, 'OOHVID'),
('VS', 'SE', 'SHES', 'TY', 'B1', 'theory', 3, 3, 'OOHVID'),
('VS', 'SE', 'SHES', 'TY', 'B1', 'theory', 4, 3, 'OOHVID'),
('VS', 'SEL', 'SHES', 'TY', 'B1', 'lab', 1, 4, 'OOHVID'),
('SS', 'PSY', 'SHES', 'SY', 'B3', 'theory', 1, 4, 'KHVHOL'),
('SS', 'PSY', 'SHES', 'SY', 'B3', 'theory', 2, 4, 'KHVHOL'),
('SS', 'PSY', 'SHES', 'SY', 'B3', 'theory', 3, 3, 'KHVHOL'),
('SS', 'PSY', 'SHES', 'SY', 'B3', 'theory', 4, 3, 'KHVHOL'),
('SS', 'PSYL', 'SHES', 'SY', 'B3', 'lab', 1, 5, 'KHVHOL'),
('SS', 'SE', 'SHES', 'TY', 'B3', 'theory', 1, 4, 'NOQERI'),
('SS', 'SE', 'SHES', 'TY', 'B3', 'theory', 2, 3, 'NOQERI'),
('SS', 'SE', 'SHES', 'TY', 'B3', 'theory', 3, 5, 'NOQERI'),
('SS', 'SE', 'SHES', 'TY', 'B3', 'theory', 4, 3, 'NOQERI'),
('SS', 'SEL', 'SHES', 'TY', 'B3', 'lab', 1, 2, 'NOQERI'),
('VS', 'PSY', 'SHES', 'SY', 'B1', 'theory', 1, 5, 'JAJQNM'),
('VS', 'PSY', 'SHES', 'SY', 'B1', 'theory', 2, 4, 'JAJQNM'),
('VS', 'PSY', 'SHES', 'SY', 'B1', 'theory', 3, 3, 'JAJQNM'),
('VS', 'PSY', 'SHES', 'SY', 'B1', 'theory', 4, 3, 'JAJQNM'),
('VS', 'PSYL', 'SHES', 'SY', 'B1', 'lab', 1, 3, 'JAJQNM'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 1, 3, 'KBEMJJ'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 2, 4, 'KBEMJJ'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 3, 3, 'KBEMJJ'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 4, 5, 'KBEMJJ'),
('VKP', 'FML', 'SMCE', 'TY', 'B5', 'lab', 1, 5, 'KBEMJJ'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 1, 4, 'OAHFBO'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 2, 5, 'OAHFBO'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 3, 3, 'OAHFBO'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 4, 5, 'OAHFBO'),
('VKP', 'FML', 'SMCE', 'TY', 'B5', 'lab', 1, 2, 'OAHFBO'),
('RAW', 'AD', 'SMCE', 'SY', 'B1', 'theory', 1, 4, 'LLUXDX'),
('AMM', 'MP', 'SMCE', 'SY', 'B1', 'theory', 1, 3, 'LLUXDX'),
('RAW', 'AD', 'SMCE', 'SY', 'B1', 'theory', 2, 5, 'LLUXDX'),
('AMM', 'MP', 'SMCE', 'SY', 'B1', 'theory', 2, 5, 'LLUXDX'),
('RAW', 'AD', 'SMCE', 'SY', 'B1', 'theory', 3, 5, 'LLUXDX'),
('AMM', 'MP', 'SMCE', 'SY', 'B1', 'theory', 3, 5, 'LLUXDX'),
('RAW', 'AD', 'SMCE', 'SY', 'B1', 'theory', 4, 5, 'LLUXDX'),
('AMM', 'MP', 'SMCE', 'SY', 'B1', 'theory', 4, 5, 'LLUXDX'),
('RAW', 'AD', 'SMCE', 'SY', 'B3', 'theory', 1, 4, 'UOXXAI'),
('RAW', 'AD', 'SMCE', 'SY', 'B3', 'theory', 2, 5, 'UOXXAI'),
('RAW', 'AD', 'SMCE', 'SY', 'B3', 'theory', 3, 3, 'UOXXAI'),
('RAW', 'AD', 'SMCE', 'SY', 'B3', 'theory', 4, 4, 'UOXXAI'),
('RAW', 'ADL', 'SMCE', 'SY', 'B3', 'lab', 1, 3, 'UOXXAI'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 1, 4, 'NYCBZO'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 2, 4, 'NYCBZO'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 3, 5, 'NYCBZO'),
('VKP', 'FM', 'SMCE', 'TY', 'B5', 'theory', 4, 4, 'NYCBZO'),
('VKP', 'FML', 'SMCE', 'TY', 'B5', 'lab', 1, 3, 'NYCBZO'),
('RAW', 'AD', 'SMCE', 'SY', 'B3', 'theory', 1, 1, 'RCYCAY'),
('RAW', 'AD', 'SMCE', 'SY', 'B3', 'theory', 2, 2, 'RCYCAY'),
('RAW', 'AD', 'SMCE', 'SY', 'B3', 'theory', 3, 1, 'RCYCAY'),
('RAW', 'AD', 'SMCE', 'SY', 'B3', 'theory', 4, 3, 'RCYCAY'),
('RAW', 'ADL', 'SMCE', 'SY', 'B3', 'lab', 1, 3, 'RCYCAY'),
('AMM', 'MP', 'SMCE', 'SY', 'B5', 'theory', 1, 1, 'OWULLS'),
('AMM', 'MP', 'SMCE', 'SY', 'B5', 'theory', 2, 2, 'OWULLS'),
('AMM', 'MP', 'SMCE', 'SY', 'B5', 'theory', 3, 1, 'OWULLS'),
('AMM', 'MP', 'SMCE', 'SY', 'B5', 'theory', 4, 3, 'OWULLS'),
('AMM', 'MP', 'SMCE', 'SY', 'B5', 'theory', 1, 5, 'PRJTYL'),
('AMM', 'MP', 'SMCE', 'SY', 'B5', 'theory', 2, 4, 'PRJTYL'),
('AMM', 'MP', 'SMCE', 'SY', 'B5', 'theory', 3, 4, 'PRJTYL'),
('AMM', 'MP', 'SMCE', 'SY', 'B5', 'theory', 4, 5, 'PRJTYL'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 1, 4, 'zzzzzz'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 1, 5, 'zzzzzz'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 1, 2, 'zzzzzz'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 2, 3, 'zzzzzz'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 2, 4, 'zzzzzz'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 2, 5, 'zzzzzz'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 3, 4, 'zzzzzz'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 3, 3, 'zzzzzz'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 3, 1, 'zzzzzz'),
('SSM', 'CT', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'zzzzzz'),
('PPC', 'WT', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'zzzzzz'),
('SMB', 'OS', 'SCET', 'TY', 'B5', 'theory', 4, 3, 'zzzzzz'),
('SSM', 'CTL', 'SCET', 'TY', 'B5', 'lab', 1, 5, 'zzzzzz'),
('PPC', 'WTL', 'SCET', 'TY', 'B5', 'lab', 1, 5, 'zzzzzz'),
('SMB', 'OSL', 'SCET', 'TY', 'B5', 'lab', 1, 5, 'zzzzzz'),
('PRH', 'HT', 'SMCE', 'TY', 'B3', 'theory', 1, 5, 'AMHZOW'),
('PRH', 'HT', 'SMCE', 'TY', 'B3', 'theory', 2, 5, 'AMHZOW'),
('PRH', 'HT', 'SMCE', 'TY', 'B3', 'theory', 3, 5, 'AMHZOW'),
('PRH', 'HT', 'SMCE', 'TY', 'B3', 'theory', 4, 5, 'AMHZOW');

-- --------------------------------------------------------

--
-- Table structure for table `student_tokens`
--

DROP TABLE IF EXISTS `student_tokens`;
CREATE TABLE IF NOT EXISTS `student_tokens` (
  `token` varchar(10) DEFAULT NULL,
  `prn` varchar(10) NOT NULL,
  `dept` varchar(8) DEFAULT NULL,
  `year` varchar(5) DEFAULT NULL,
  `block` varchar(2) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `UNQ_prn` (`prn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_tokens`
--

INSERT INTO `student_tokens` (`token`, `prn`, `dept`, `year`, `block`, `name`, `status`) VALUES
('aaaaaa', '1111111111', 'SCET', 'TY', 'B5', 'aaa', 1),
('bbbbbb', '2222222222', 'SCET', 'TY', 'B5', 'bbb', 1),
('cccccc', '3333333333', 'SCET', 'TY', 'B5', 'ccc', 1),
('dddddd', '4444444444', 'SCET', 'TY', 'B5', 'ccc', 1),
('eeeeee', '5555555555', 'SCET', 'TY', 'B5', 'eee', 1),
('ffffff', '6666666666', 'SCET', 'TY', 'B5', 'fff', 1),
('gggggg', '777777777', 'SCET', 'TY', 'B5', 'ggg', 1),
('JLTXVV', '8695326238', 'SHES', 'SY', 'B3', 'JLT', 1),
('KBEMJJ', '4549361181', 'SMCE', 'TY', 'B5', 'KBE', 1),
('OOHVID', '5618414764', 'SHES', 'TY', 'B1', 'OOH', 1),
('OAHFBO', '6166151399', 'SMCE', 'TY', 'B5', 'OAH', 1),
('LLUXDX', '2391152588', 'SMCE', 'SY', 'B1', 'LLU', 1),
('UOXXAI', '8395922728', 'SMCE', 'SY', 'B3', 'UOX', 1),
('NYCBZO', '1597166158', 'SMCE', 'TY', 'B5', 'NYC', 1),
('KHVHOL', '2754312497', 'SHES', 'SY', 'B3', 'KHV', 1),
('JGKRVP', '1738493839', 'SCET', 'SY', 'B1', 'JGK', 1),
('NWHMUC', '1274558644', 'SCET', 'TY', 'B5', 'NWH', 1),
('RCYCAY', '8826783791', 'SMCE', 'SY', 'B3', 'RCY', 1),
('JVVXSF', '9322549482', 'SCET', 'TY', 'B1', 'JVV', 1),
('MHVMBB', '7644343298', 'SCET', 'SY', 'B5', 'MHV', 1),
('ZQQSOB', '2876249569', 'SCET', 'SY', 'B1', 'ZQQ', 1),
('OWULLS', '8488524381', 'SMCE', 'SY', 'B5', 'OWU', 1),
('HLOXDZ', '5853737686', 'SCET', 'SY', 'B5', 'HLO', 1),
('CWCNKY', '5624353597', 'SCET', 'TY', 'B1', 'CWC', 1),
('PONTZT', '5861778169', 'SCET', 'TY', 'B1', 'PON', 1),
('NOQERI', '1268256913', 'SHES', 'TY', 'B3', 'NOQ', 1),
('FIRSSC', '9264744689', 'SCET', 'SY', 'B3', 'FIR', 1),
('JAJQNM', '7678661435', 'SHES', 'SY', 'B1', 'JAJ', 1),
('PRJTYL', '2656959992', 'SMCE', 'SY', 'B5', 'PRJ', 1),
('zzzzzz', '9999999999', 'SCET', 'TY', 'B5', 'zzz', 1),
('JOPKFB', '9177888157', 'SHES', 'TY', 'B1', 'JOP', 0),
('HHDHWL', '5923658468', 'SCET', 'SY', 'B5', 'HHD', 0),
('NFZZFV', '9243544613', 'SMCE', 'TY', 'B3', 'NFZ', 0),
('YEODSN', '2761539728', 'SCET', 'SY', 'B3', 'YEO', 0),
('ZKHGSF', '7354277293', 'SCET', 'SY', 'B3', 'ZKH', 0),
('QGUNBB', '2866113366', 'SCET', 'SY', 'B5', 'QGU', 0),
('KOIHLH', '6841914692', 'SMCE', 'SY', 'B1', 'KOI', 0),
('WUHQHD', '6661791854', 'SMCE', 'TY', 'B5', 'WUH', 0),
('SZZDJR', '8689712426', 'SCET', 'SY', 'B3', 'SZZ', 0),
('QFLNQK', '7767231149', 'SMCE', 'SY', 'B3', 'QFL', 0),
('WWSKSA', '3737515554', 'SHES', 'SY', 'B1', 'WWS', 0),
('LBSTVQ', '6811557389', 'SCET', 'SY', 'B5', 'LBS', 0),
('DPNQYD', '3954134328', 'SHES', 'TY', 'B3', 'DPN', 0),
('AMHZOW', '6348888274', 'SMCE', 'TY', 'B3', 'AMH', 1),
('YJKAJW', '2854636418', 'SMCE', 'SY', 'B1', 'YJK', 0),
('VZNOMM', '3228877664', 'SCET', 'SY', 'B1', 'VZN', 0),
('EQKYWC', '4197988392', 'SHES', 'TY', 'B5', 'EQK', 0),
('BYJPHG', '5377112697', 'SCET', 'TY', 'B1', 'BYJ', 0),
('PGCBTX', '9917169981', 'SHES', 'TY', 'B5', 'PGC', 0),
('AVBVIB', '4644355385', 'SCET', 'TY', 'B1', 'AVB', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
